import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.net.StandardSocketOptions;

/**
 *
 * @author axel
 */
public class Servidor {
  public static void main(String[] args){
      try{
         ServerSocket s = new ServerSocket(1234);
         s.setOption(StandardSocketOptions.SO_REUSEADDR, true);
          System.out.println("SO_RCVBUF: "+s.getOption(StandardSocketOptions.SO_RCVBUF));
          System.out.println("Servidor iniciado en el puerto:"+s.getLocalPort());
          for(;;){
              Socket cl =s.accept();
              System.out.println("Cliente conectado desde "+cl.getInetAddress()+":"+cl.getPort());
//              PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream(),"ISO-8859-1"));
//              BufferedReader br = new BufferedReader(new InputStreamReader(cl.getInputStream(),"ISO-8859-1"));
//              String nombre = br.readLine();
//              System.out.println("Devolviendo saludo a "+nombre);
//              pw.println("hola "+nombre+", recibe un saludo desde el servidor de flujo..");
//DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
//DataInputStream dis = new DataInputStream(cl.getInputStream());
ObjectOutputStream oos = new ObjectOutputStream(cl.getOutputStream());
ObjectInputStream ois = new ObjectInputStream(cl.getInputStream());
int v1 = ois.readInt();
float v2 = ois.readFloat();
String v3 = ois.readUTF();
System.out.println("Datos recibidos v1:"+v1+" v2:"+v2+" v3:"+v3);
Dato d = (Dato)ois.readObject();
System.out.println("Objeto recibido: v1:"+d.v1+" v2:"+d.v2+" v3:"+d.v3);

oos.writeInt(6);
oos.writeFloat(7.0f);
oos.writeUTF("ocho");
oos.flush();
Dato d1 = new Dato(5,5.0f,"cinco");
oos.writeObject(d1);
oos.flush();
ois.close();
oos.close();

//                        
              
              
//              pw.flush();
//              pw.close();
//              br.close();
              cl.close();
              
          }//for
      }catch(Exception io){
          io.printStackTrace();
      }
  }//main    
}
