/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package cm1;

/**
 *
 * @author axel
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
