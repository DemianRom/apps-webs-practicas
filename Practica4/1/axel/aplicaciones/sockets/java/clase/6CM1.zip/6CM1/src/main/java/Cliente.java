import java.net.Socket;
import java.io.*;
/**
 *
 * @author axel
 */
public class Cliente {
    public static void main(String[] args){
        try{
            Socket cl = new Socket("::1",1234);
            System.out.println("Cliente conectado a la direccion "+cl.getInetAddress()+":"+cl.getPort());
//            DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
//            DataInputStream dis = new DataInputStream(cl.getInputStream());
            ObjectOutputStream oos = new ObjectOutputStream(cl.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(cl.getInputStream());
            oos.writeInt(1);
            oos.writeFloat(2.0f);
            oos.writeUTF("tres");
            Dato d = new Dato(9,9.0f,"nueve");
            oos.writeObject(d);
            oos.flush();
            int v1 = ois.readInt();
            float v2 = ois.readFloat();
            String v3 = ois.readUTF();
            System.out.println("Datos recibidos v1:"+v1+" v2:"+v2+" v3:"+v3);
            Dato d1 = (Dato)ois.readObject();
            System.out.println("Objeto recibido: v1:"+d1.v1+" v2:"+d1.v2+" v3:"+d1.v3);
            ois.close();
            oos.close();
//            System.out.println("Escribe tu nombre:");
//            BufferedReader br = new BufferedReader(new InputStreamReader(System.in,"ISO-8859-1"));
//            String nombre = br.readLine();
//            PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream(),"ISO-8859-1"));
//            pw.println(nombre);
//            pw.flush();
//            BufferedReader br2 = new BufferedReader(new InputStreamReader(cl.getInputStream(),"ISO-8859-1"));
//            String saludo = br2.readLine();
//            System.out.println("Recibiendo mensaje desde el servidor: "+saludo);
//            br2.close();
//            br.close();
//            pw.close();
            cl.close();
        }catch(Exception e){
           e.printStackTrace();
        }//
    }//main
}
