import java.io.Serializable;
/**
 *
 * @author axel
 */
public class Dato implements Serializable{
    int v1;
    float v2;
    String v3;
    
    public Dato(int v1, float v2,String v3){
        this.v1=v1;
        this.v2=v2;
        this.v3=v3;
    }
}
