import java.io.*;
import java.net.*;
/**
 *
 * @author Axel
 */
public class Cliente {
    public static void main(String[] args){
        try{
            String dst = "127.0.0.1";
            int pto = 1234;
            Socket cl = new Socket(dst,pto);
            int v1 = 1;
            float v2 = 2.0f;
            String v3 = "tres";
            DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
            
            System.out.println("Enviando los siguientes datos al servidor: v1="+v1+", v2="+v2+", v3="+v3);
            dos.writeInt(v1);
            dos.writeFloat(v2);
            dos.writeUTF(v3);
            dos.flush();
            dos.close();
            /*System.out.println("Conexion establecida.. Escribe tu nombre:");
            BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
            BufferedReader br2 = new BufferedReader(new InputStreamReader(cl.getInputStream()));
            String nombre = br1.readLine();
            pw.println(nombre);
            String saludo = br2.readLine();
            System.out.println("Mensaje recibido desde el servidor con el saludo "+saludo);
            br2.close();
            br1.close();*/
            cl.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }//main
}
