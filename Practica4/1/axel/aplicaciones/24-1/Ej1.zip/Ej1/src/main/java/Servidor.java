import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.StandardSocketOptions;
/**
 *
 * @author Axel
 */
public class Servidor {
    public static void main(String[] args){
        ServerSocket s =null;
        try{
            s = new ServerSocket(1234);
            s.setOption(StandardSocketOptions.SO_REUSEADDR, true);
            System.out.println("Servidor iniciado en el pruerto "+s.getLocalPort());
            for(;;){
                Socket cl = s.accept();
                System.out.println("Cliente conectado desde "+cl.getInetAddress()+":"+cl.getPort());
                DataInputStream dis = new DataInputStream(cl.getInputStream());
                int v1 = dis.readInt();
                float v2 = dis.readFloat();
                String v3 = dis.readUTF();
                System.out.println("Datos recibidos: v1="+v1+", v2="+v2+", v3="+v3);
                dis.close();
                /*PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
                BufferedReader br = new BufferedReader(new InputStreamReader(cl.getInputStream()));
                String nombre = br.readLine();
                System.out.println("Recibiendo mensaje de "+nombre+", devolviendo saludo..");
                String saludo ="Hola "+nombre+" recibe un saludo desde la aplicaicon servidor..";
                pw.println(saludo);
                br.close();
                pw.close();*/
                cl.close();
            }//for
            
        }catch(Exception e){
            e.printStackTrace();
        } finally {
            try{
            s.close();
            }catch(Exception e2){}
        }//finally
    }//main
}
