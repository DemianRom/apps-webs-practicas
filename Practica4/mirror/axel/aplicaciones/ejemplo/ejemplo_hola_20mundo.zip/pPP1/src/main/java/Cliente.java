
import java.net.Socket;
import java.io.*;
import java.net.StandardSocketOptions;
/**
 *
 * @author Axel
 */
public class Cliente {
    public static void main(String[] args){
        try{
            String dir = "127.0.0.1";
            int pto = 1234;
            Socket cl = new Socket(dir,pto);
            System.out.println("Cliente conectado al servidor...");
            System.out.println("SO_RCVBUF="+cl.getOption(StandardSocketOptions.SO_RCVBUF));
            System.out.println("SO_SNDBUF="+cl.getOption(StandardSocketOptions.SO_SNDBUF));
            System.out.println("TCP_NODELAY="+cl.getOption(StandardSocketOptions.TCP_NODELAY));
            DataInputStream dis = new DataInputStream(cl.getInputStream());
            int v1 = dis.readInt();
            float v2 = dis.readFloat();
            String v3 = dis.readUTF();
            //BufferedReader br = new BufferedReader(new InputStreamReader(cl.getInputStream()));
            //String mensaje = br.readLine();
            System.out.println("Mensaje recibido desde el servidor con los datos-> v1:"+v1+" v2:"+v2+" v3:"+v3);
            //br.close();
            dis.close();
            cl.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }//main
}
