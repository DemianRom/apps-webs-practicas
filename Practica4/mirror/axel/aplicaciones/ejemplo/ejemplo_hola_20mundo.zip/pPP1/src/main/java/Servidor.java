
import java.net.*;
import java.io.*;
/**
 *
 * @author Axel
 */
public class Servidor {
    public static void main(String[] args){
        try{
            ServerSocket s = new ServerSocket(1234);
            System.out.println("Servicio iniciado en el puerto "+s.getLocalPort()+"  Esperando por clientes..");
            for(;;){  //while(1)
                Socket cl = s.accept();
                System.out.println("Cliente conectado desde "+cl.getInetAddress()+":"+cl.getPort());
                String saludo = "Saludos desde la aplicacion servidor por socket de flujo.";
               // PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream()));
                //pw.println(saludo);
                //pw.close();
                DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
                dos.writeInt(1);
                dos.writeFloat(2.0f);
                dos.writeUTF("tres");
                dos.close();
                cl.close();
            }//for
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//main
}
