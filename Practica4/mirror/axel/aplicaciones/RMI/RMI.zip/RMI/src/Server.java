//package hello;
	
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
	
public class Server implements Suma {
	
    public Server() {}

    public int suma(int a, int b)throws RemoteException {
	return a+b;
    }
    public int resta(int a, int b){
	return a-b;
    }
    public int producto(int a, int b) {
	return a*b;
    }
    
        public Dato getDato(int a, float b)throws RemoteException {
	return new Dato(a,b);
    }
    public static void main(String args[]) {
	try {
		 java.rmi.registry.LocateRegistry.createRegistry(1099); //puerto default del rmiregistry
		 System.out.println("Registro RMI iniciado...");
	  } catch (Exception e) {
		 System.out.println("Excepcion al iniciar registro RMI:");
		 e.printStackTrace();
	  }//catch
	
	try {
		System.setProperty("java.rmi.server.codebase","file:///D:\\Documentos\\NetBeansProjects\\RMI\\build\\classes\\");
                //System.setProperty("java.rmi.server.codebase","HTTP://127.0.0.1/");
                System.setProperty("java.security.policy","permisos.policy");
                
	    Server obj = new Server();
	    Suma stub = (Suma) UnicastRemoteObject.exportObject(obj, 0);

	    // Bind the remote object's stub in the registry
	    Registry registry = LocateRegistry.getRegistry();
	    registry.bind("Suma", stub);

	    System.err.println("Servidor listo...");
	} catch (Exception e) {
	    System.err.println("Server exception: " + e.toString());
	    e.printStackTrace();
	}
    }
}
