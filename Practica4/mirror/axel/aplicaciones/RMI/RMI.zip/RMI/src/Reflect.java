import java.lang.reflect.*;
import java.io.*;

 
   public class Reflect {
      public static void main(String args[])
      {
         try {
             BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
             for(;;){
             System.out.println("Escribe el nombre canonico de la clase:");
             String clase = br.readLine();
             Class c = Class.forName(clase);
             Constructor con[] = c.getDeclaredConstructors();
             System.out.println("Constructores disponibles:");
            for (int i = 0; i < con.length; i++)
               System.out.println(con[i].toString());
            System.out.println("\n");
            Method m[] = c.getDeclaredMethods();
                 System.out.println("Metodos disponibles:");
            for (int i = 0; i < m.length; i++)
               System.out.println(m[i].toString());
            System.out.println("\n");
             }//for
             
         } catch (Throwable e) {
            System.err.println(e);
         }
      }
   }