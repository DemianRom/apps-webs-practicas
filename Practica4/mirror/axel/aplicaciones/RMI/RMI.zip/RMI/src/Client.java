//package hello;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {

    private Client() {}

    public static void main(String[] args) {

	String host = (args.length < 1) ? null : args[0];
	try {
		
	    Registry registry = LocateRegistry.getRegistry(host);	
//tambien puedes usar getRegistry(String host, int port)
	    //System.setProperty("java.rmi.server.codebase","HTTP://192.168.1.70:8000/");
	    Suma stub = (Suma) registry.lookup("Suma");
	    int x=5,y=4;
	    int response = stub.suma(x,y);
	    
	    System.out.println("respuesta sumar "+x+" y "+y+" : " + response);
            Dato d = stub.getDato(4,5.1f);
            System.out.println("Dato recibido, a->"+d.getA()+", b->"+d.getB());
	} catch (Exception e) {
	    System.err.println("Client exception: " + e.toString());
	    e.printStackTrace();
	}
    }
}
