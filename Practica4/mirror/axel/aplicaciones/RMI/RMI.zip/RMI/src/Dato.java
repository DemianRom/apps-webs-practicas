import java.io.Serializable;
//import java.util.Random;
/**
 *
 * @author axel
 */
public class Dato implements Serializable{
    int a;
    float b;
    //Random r;
    
    public  Dato(int a, float b){
      //r = new Random(11);    
        this.a = a;
        this.b = b;
    }
    
    int getA(){
        return this.a;
    }
    
    float getB(){
        return this.b;
    }
    
}
