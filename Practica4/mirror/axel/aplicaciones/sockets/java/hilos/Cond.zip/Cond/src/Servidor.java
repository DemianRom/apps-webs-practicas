import java.io.*;
import java.net.*;
import java.util.concurrent.ConcurrentHashMap;

public class Servidor {
    private static final int PUERTO = 9876;
    private static final int BUFFER_SIZE = 4096;
    private static ConcurrentHashMap<String, FileOutputStream> archivosActivos = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(PUERTO)) {
            System.out.println("Servidor iniciado en el puerto " + PUERTO);
            
            byte[] buffer = new byte[BUFFER_SIZE + 256]; // Buffer para datos + metadatos
            
            while (true) {
                DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);
                socket.receive(paquete);
                
                // Procesar el paquete en un hilo separado
                new HiloManejadorCliente(paquete, socket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    static class HiloManejadorCliente extends Thread {
        private DatagramPacket paqueteInicial;
        private DatagramSocket socket;
        
        public HiloManejadorCliente(DatagramPacket paquete, DatagramSocket socket) {
            this.paqueteInicial = paquete;
            this.socket = socket;
        }
        
        @Override
        public void run() {
            try {
                byte[] datos = paqueteInicial.getData();
                int offset = 0;
                
                // Leer tipo de mensaje (0: metadatos, 1: datos, 2: fin, 3: error)
                int tipo = bytesToInt(datos, offset);
                offset += 4;
                
                if (tipo == 0) { // Metadatos del archivo
                    // Leer nombre del archivo
                    int nombreLength = bytesToInt(datos, offset);
                    offset += 4;
                    String nombreArchivo = new String(datos, offset, nombreLength);
                    offset += nombreLength;
                    
                    // Leer ID de transmisión
                    String idTransmision = new String(datos, offset, 36);
                    
                    System.out.println("Recibiendo archivo: " + nombreArchivo + " (ID: " + idTransmision + ")");
                    
                    // Crear archivo de destino
                    File archivoDestino = new File("recibido_" + nombreArchivo);
                    FileOutputStream fos = new FileOutputStream(archivoDestino);
                    archivosActivos.put(idTransmision, fos);
                    
                    // Enviar confirmación
                    enviarConfirmacion(socket, paqueteInicial.getAddress(), paqueteInicial.getPort(), idTransmision, true);
                    
                } else if (tipo == 1) { // Datos del archivo
                    // Leer ID de transmisión
                    String idTransmision = new String(datos, offset, 36);
                    offset += 36;
                    
                    // Leer secuencia
                    int secuencia = bytesToInt(datos, offset);
                    offset += 4;
                    
                    // Leer longitud de datos
                    int longitudDatos = bytesToInt(datos, offset);
                    offset += 4;
                    
                    FileOutputStream fos = archivosActivos.get(idTransmision);
                    if (fos != null) {
                        fos.write(datos, offset, longitudDatos);
                        fos.flush();
                        System.out.println("Recibido paquete " + secuencia + " para " + idTransmision + " (" + longitudDatos + " bytes)");
                    }
                    
                } else if (tipo == 2) { // Fin de transmisión
                    String idTransmision = new String(datos, offset, 36);
                    FileOutputStream fos = archivosActivos.get(idTransmision);
                    if (fos != null) {
                        fos.close();
                        archivosActivos.remove(idTransmision);
                        System.out.println("Transmisión completada: " + idTransmision);
                    }
                    
                } else if (tipo == 3) { // Error
                    String idTransmision = new String(datos, offset, 36);
                    FileOutputStream fos = archivosActivos.get(idTransmision);
                    if (fos != null) {
                        fos.close();
                        archivosActivos.remove(idTransmision);
                        // Eliminar archivo incompleto
                        new File("recibido_" + idTransmision.split("_")[0]).delete();
                        System.out.println("Transmisión cancelada: " + idTransmision);
                    }
                }
                
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        private void enviarConfirmacion(DatagramSocket socket, InetAddress direccion, int puerto, String idTransmision, boolean exito) {
            try {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(baos);
                
                dos.writeInt(exito ? 1 : 0); // 1: éxito, 0: error
                dos.flush();
                dos.writeUTF(idTransmision);
                dos.flush();
                
                byte[] datosConfirmacion = baos.toByteArray();
                DatagramPacket paqueteConfirmacion = new DatagramPacket(
                    datosConfirmacion, datosConfirmacion.length, direccion, puerto);
                socket.send(paqueteConfirmacion);
                
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        private int bytesToInt(byte[] bytes, int offset) {
            return ((bytes[offset] & 0xFF) << 24) |
                   ((bytes[offset + 1] & 0xFF) << 16) |
                   ((bytes[offset + 2] & 0xFF) << 8) |
                   (bytes[offset + 3] & 0xFF);
        }
    }
}