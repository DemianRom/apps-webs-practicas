import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Cliente {
    private static final String SERVIDOR = "localhost";
    private static final int PUERTO = 9876;
    private static final int BUFFER_SIZE = 4096;
    
    private static Map<String, HiloTransmisor> transmisionesActivas = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Cliente iniciado. Comandos disponibles:");
        System.out.println("- enviar <archivo>: Enviar un archivo");
        System.out.println("- pausar <id>: Pausar transmisión");
        System.out.println("- reanudar <id>: Reanudar transmisión");
        System.out.println("- detener <id>: Detener transmisión");
        System.out.println("- listar: Listar transmisiones activas");
        System.out.println("- salir: Salir del programa");
        
        while (true) {
            System.out.print("\nComando: ");
            String comando = scanner.nextLine().trim();
            
            if (comando.startsWith("enviar ")) {
                String nombreArchivo = comando.substring(7);
                enviarArchivo(nombreArchivo);
                
            } else if (comando.startsWith("pausar ")) {
                String id = comando.substring(7);
                pausarTransmision(id);
                
            } else if (comando.startsWith("reanudar ")) {
                String id = comando.substring(9);
                reanudarTransmision(id);
                
            } else if (comando.startsWith("detener ")) {
                String id = comando.substring(8);
                detenerTransmision(id);
                
            } else if (comando.equals("listar")) {
                listarTransmisiones();
                
            } else if (comando.equals("salir")) {
                System.out.println("Saliendo...");
                // Detener todas las transmisiones activas
                for (HiloTransmisor transmisor : transmisionesActivas.values()) {
                    transmisor.detener();
                }
                break;
            } else {
                System.out.println("Comando no reconocido");
            }
        }
        
        scanner.close();
    }
    
    private static void enviarArchivo(String nombreArchivo) {
        File archivo = new File(nombreArchivo);
        if (!archivo.exists()) {
            System.out.println("El archivo no existe: " + nombreArchivo);
            return;
        }
        
        String idTransmision = UUID.randomUUID().toString();
        HiloTransmisor transmisor = new HiloTransmisor(archivo, idTransmision);
        transmisionesActivas.put(idTransmision, transmisor);
        transmisor.start();
        
        System.out.println("Transmisión iniciada. ID: " + idTransmision);
    }
    
    private static void pausarTransmision(String id) {
        HiloTransmisor transmisor = transmisionesActivas.get(id);
        if (transmisor != null) {
            transmisor.pausar();
            System.out.println("Transmisión pausada: " + id);
        } else {
            System.out.println("Transmisión no encontrada: " + id);
        }
    }
    
    private static void reanudarTransmision(String id) {
        HiloTransmisor transmisor = transmisionesActivas.get(id);
        if (transmisor != null) {
            transmisor.reanudar();
            System.out.println("Transmisión reanudada: " + id);
        } else {
            System.out.println("Transmisión no encontrada: " + id);
        }
    }
    
    private static void detenerTransmision(String id) {
        HiloTransmisor transmisor = transmisionesActivas.get(id);
        if (transmisor != null) {
            transmisor.detener();
            transmisionesActivas.remove(id);
            System.out.println("Transmisión detenida: " + id);
        } else {
            System.out.println("Transmisión no encontrada: " + id);
        }
    }
    
    private static void listarTransmisiones() {
        if (transmisionesActivas.isEmpty()) {
            System.out.println("No hay transmisiones activas");
            return;
        }
        
        System.out.println("Transmisiones activas:");
        for (Map.Entry<String, HiloTransmisor> entry : transmisionesActivas.entrySet()) {
            String estado = entry.getValue().estaPausado() ? "PAUSADO" : "TRANSMITIENDO";
            System.out.println("ID: " + entry.getKey() + " - Estado: " + estado);
        }
    }
    
    static class HiloTransmisor extends Thread {
        private File archivo;
        private String idTransmision;
        private DatagramSocket socket;
        private InetAddress direccionServidor;
        
        private volatile boolean transmisionActiva = true;
        private volatile boolean pausado = false;
        private final ReentrantLock lock = new ReentrantLock();
        private final Condition condicion = lock.newCondition();
        
        public HiloTransmisor(File archivo, String idTransmision) {
            this.archivo = archivo;
            this.idTransmision = idTransmision;
        }
        
        @Override
        public void run() {
            try {
                socket = new DatagramSocket();
                direccionServidor = InetAddress.getByName(SERVIDOR);
                
                // Enviar metadatos del archivo
                if (!enviarMetadatos()) {
                    System.out.println("Error al enviar metadatos para: " + idTransmision);
                    return;
                }
                
                // Enviar datos del archivo
                enviarDatosArchivo();
                
            } catch (IOException e) {
                System.out.println("Error en transmisión " + idTransmision + ": " + e.getMessage());
            } finally {
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                }
                transmisionesActivas.remove(idTransmision);
            }
        }
        
        private boolean enviarMetadatos() throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            
            // Tipo: 0 = metadatos
            dos.writeInt(0);
            dos.flush();
            
            // Nombre del archivo
            byte[] nombreBytes = archivo.getName().getBytes();
            dos.writeInt(nombreBytes.length);
            dos.flush();
            dos.write(nombreBytes);
            dos.flush();
            
            
            // ID de transmisión
            dos.write(idTransmision.getBytes(), 0, 36);
            dos.flush();
            
            byte[] datos = baos.toByteArray();
            DatagramPacket paquete = new DatagramPacket(datos, datos.length, direccionServidor, PUERTO);
            socket.send(paquete);
            
            // Esperar confirmación
            return esperarConfirmacion();
        }
        
        private void enviarDatosArchivo() throws IOException {
            try (FileInputStream fis = new FileInputStream(archivo)) {
                byte[] buffer = new byte[BUFFER_SIZE];
                int bytesLeidos;
                int secuencia = 0;
                
                while (transmisionActiva && (bytesLeidos = fis.read(buffer)) != -1) {
                    // Verificar si está pausado
                    lock.lock();
                    try {
                        while (pausado && transmisionActiva) {
                            condicion.await();
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    } finally {
                        lock.unlock();
                    }
                    
                    if (!transmisionActiva) {
                        break;
                    }
                    
                    // Enviar paquete de datos
                    if (!enviarPaqueteDatos(buffer, bytesLeidos, secuencia)) {
                        System.out.println("Error al enviar paquete " + secuencia + " para " + idTransmision);
                        break;
                    }
                    
                    secuencia++;
                    System.out.println("Enviado paquete " + secuencia + " para " + idTransmision + " (" + bytesLeidos + " bytes)");
                    
                    // Pequeña pausa para no saturar
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                
                if (transmisionActiva) {
                    // Enviar fin de transmisión
                    enviarFinTransmision();
                    System.out.println("Transmisión completada: " + idTransmision);
                } else {
                    // Enviar cancelación
                    enviarCancelacion();
                    System.out.println("Transmisión cancelada: " + idTransmision);
                }
            }
        }
        
        private boolean enviarPaqueteDatos(byte[] datos, int longitud, int secuencia) throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            
            // Tipo: 1 = datos
            dos.writeInt(1);
            dos.flush();
            
            // ID de transmisión
            dos.write(idTransmision.getBytes(), 0, 36);
            dos.flush();
            
            // Número de secuencia
            dos.writeInt(secuencia);
            dos.flush();
            
            // Longitud de datos
            dos.writeInt(longitud);
            dos.flush();
            
            // Datos
            dos.write(datos, 0, longitud);
            dos.flush();
            
            byte[] paqueteDatos = baos.toByteArray();
            DatagramPacket paquete = new DatagramPacket(paqueteDatos, paqueteDatos.length, direccionServidor, PUERTO);
            socket.send(paquete);
            
            return esperarConfirmacion();
        }
        
        private void enviarFinTransmision() throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            
            // Tipo: 2 = fin
            dos.writeInt(2);
            dos.flush();
            dos.write(idTransmision.getBytes(), 0, 36);
            dos.flush();
            
            byte[] datos = baos.toByteArray();
            DatagramPacket paquete = new DatagramPacket(datos, datos.length, direccionServidor, PUERTO);
            socket.send(paquete);
        }
        
        private void enviarCancelacion() throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(baos);
            
            // Tipo: 3 = error/cancelación
            dos.writeInt(3);
            dos.flush();
            dos.write(idTransmision.getBytes(), 0, 36);
            dos.flush();
            
            byte[] datos = baos.toByteArray();
            DatagramPacket paquete = new DatagramPacket(datos, datos.length, direccionServidor, PUERTO);
            socket.send(paquete);
        }
        
        private boolean esperarConfirmacion() {
            try {
                byte[] buffer = new byte[256];
                DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);
                socket.setSoTimeout(5000); // Timeout de 5 segundos
                socket.receive(paquete);
                
                ByteArrayInputStream bais = new ByteArrayInputStream(paquete.getData());
                DataInputStream dis = new DataInputStream(bais);
                
                int resultado = dis.readInt();
                String idConfirmacion = dis.readUTF();
                
                return resultado == 1 && idTransmision.equals(idConfirmacion);
                
            } catch (SocketTimeoutException e) {
                System.out.println("Timeout esperando confirmación para: " + idTransmision);
                return false;
            } catch (IOException e) {
                System.out.println("Error esperando confirmación para: " + idTransmision);
                return false;
            }
        }
        
        public void pausar() {
            lock.lock();
            try {
                pausado = true;
            } finally {
                lock.unlock();
            }
        }
        
        public void reanudar() {
            lock.lock();
            try {
                pausado = false;
                condicion.signalAll();
            } finally {
                lock.unlock();
            }
        }
        
        public void detener() {
            transmisionActiva = false;
            reanudar(); // Despertar el hilo si está pausado
            interrupt();
        }
        
        public boolean estaPausado() {
            return pausado;
        }
    }
}