import javax.sound.sampled.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class AudioStreamingClient {
    private static final int PORT = 9876;
    private static final int BUFFER_SIZE = 50000;//4096;
    private static final int CIRCULAR_BUFFER_SIZE = 10; // Tamaño del buffer circular

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(PORT);
            byte[] buffer = new byte[BUFFER_SIZE];
            AudioFormat format = new AudioFormat(44100, 16, 2, true, false);
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            SourceDataLine audioLine = (SourceDataLine) AudioSystem.getLine(info);
            audioLine.open(format);
            audioLine.start();

            byte[][] circularBuffer = new byte[CIRCULAR_BUFFER_SIZE][BUFFER_SIZE];
            int head = 0;
            int tail = 0;
            int cont = 0;

            while (true) {
                DatagramPacket packet = new DatagramPacket(buffer, BUFFER_SIZE);
                socket.receive(packet);
                circularBuffer[head] = packet.getData().clone();
                System.out.println("recibiendo paquete " +(cont++)+" con "+circularBuffer[head].length+" bytes");
                head = (head + 1) % CIRCULAR_BUFFER_SIZE;

                if (head == tail) {
                    tail = (tail + 1) % CIRCULAR_BUFFER_SIZE;
                }

                audioLine.write(circularBuffer[tail], 0, BUFFER_SIZE);
                audioLine.flush();
                System.out.println("acabo de mandar reproducir "+circularBuffer[tail].length+" bytes");
                tail = (tail + 1) % CIRCULAR_BUFFER_SIZE;
                System.out.println("siguiente indice del buffer a ser reproducido: "+tail);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
