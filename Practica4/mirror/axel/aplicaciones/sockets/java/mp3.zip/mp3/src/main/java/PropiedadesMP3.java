
import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO; 
import org.jaudiotagger.audio.exceptions.CannotReadException; 
import org.jaudiotagger.audio.exceptions.InvalidAudioFrameException; 
import org.jaudiotagger.audio.exceptions.ReadOnlyFileException; 
import org.jaudiotagger.audio.mp3.MP3AudioHeader; 
import org.jaudiotagger.tag.TagException; 
import java.io.File; 
import java.io.IOException; 
public class PropiedadesMP3 { 
    public static void main(String[] args) 
    { 
        // Ruta al archivo MP3 
        String filePath = "Beautiful_Things.mp3"; 
        try { 
            // Cargar el archivo MP3 
            File mp3File = new File(filePath); 
            AudioFile audioFile = AudioFileIO.read(mp3File); 
            // Obtener el encabezado del archivo MP3 
            MP3AudioHeader audioHeader = (MP3AudioHeader) audioFile.getAudioHeader();
            // Obtener el bitrate 
            String bitrate = audioHeader.getBitRate(); 
            // Imprimir el bitrate 
            System.out.println("Bitrate del archivo MP3: " + bitrate + " kbps"); 
        } catch (CannotReadException | IOException | TagException | ReadOnlyFileException | InvalidAudioFrameException e) {
            e.printStackTrace(); 
        } 
    }
} 