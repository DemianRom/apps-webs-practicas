/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package mp3;

/**
 *
 * @author axel
 */
public class Mp3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
