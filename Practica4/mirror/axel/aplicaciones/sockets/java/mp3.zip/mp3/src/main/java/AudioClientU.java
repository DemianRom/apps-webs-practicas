import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import javazoom.jl.player.Player;
import java.io.*;

public class AudioClientU {
    private static final int PORT = 9876;
    private static final int BUFFER_SIZE = 60000;//4096;
    private static final int CIRCULAR_BUFFER_SIZE = 10 * BUFFER_SIZE;

    private static byte[] circularBuffer = new byte[CIRCULAR_BUFFER_SIZE];
    private static int writeIndex = 0;
    private static int readIndex = 0;

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(PORT);
            InetAddress address = InetAddress.getByName("localhost");

            Thread playbackThread = new Thread(() -> {
                try {
                    Player player = new Player(new CircularBufferInputStream());
                    //Thread.sleep(10);
                    player.play();
                    System.out.println("reproduciendo..");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            //playbackThread.setPriority(10); ////
            playbackThread.start();

            byte[] buffer = new byte[BUFFER_SIZE];
            while (true) {
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                socket.receive(packet);
                System.out.println("recibiendo paquete con "+ packet.getLength()+" bytes");
                //synchronized (circularBuffer) {
                    for (int i = 0; i < packet.getLength(); i++) {
                        circularBuffer[writeIndex] = buffer[i];
                        //System.out.printf("%02x ",circularBuffer[writeIndex]);
                        writeIndex = (writeIndex + 1) % CIRCULAR_BUFFER_SIZE;
                        
                    }
               // }//synchronized
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*private*/ static class CircularBufferInputStream extends java.io.InputStream {
        @Override
        public int read() throws IOException {
            //synchronized (circularBuffer) {
                if (readIndex == writeIndex) {
                    System.err.println("No hay datos disponibles para leer..");
                    return -1; // No hay datos disponibles
                }
                int data = circularBuffer[readIndex] & 0xFF;
                System.err.println("se leyo 1 byte: "+data);
                readIndex = (readIndex + 1) % CIRCULAR_BUFFER_SIZE;
                return data;
            //}//synchronized
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            synchronized (circularBuffer) {
                int available = (writeIndex - readIndex + CIRCULAR_BUFFER_SIZE) % CIRCULAR_BUFFER_SIZE;
                System.err.println("available: "+available+" bytes");
                if (available == 0) {
                    System.err.println("No hay bloques de datos disponibles para leer..");
                    return -1; // No hay datos disponibles
                }
                int bytesToRead = Math.min(len, available);
                for (int i = 0; i < bytesToRead; i++) {
                    b[off + i] = circularBuffer[readIndex];
                    readIndex = (readIndex + 1) % CIRCULAR_BUFFER_SIZE;
                }
                System.err.println("leyendo "+bytesToRead+" bytes");
                return bytesToRead;
            }
        }
    }
}
