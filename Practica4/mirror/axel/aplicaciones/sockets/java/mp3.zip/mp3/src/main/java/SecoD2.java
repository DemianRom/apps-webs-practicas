import java.net.*;
import java.io.*;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class SecoD2 {
    public static void main(String[] args) {
        try {
            int pto = 9999, tam = 40000;
            DatagramSocket s = new DatagramSocket(pto);
            s.setReuseAddress(true);
            System.out.println("Servidor de streaming iniciado... esperando datagramas..");

            for (;;) {
                // 1. Recibir metadatos
                byte[] bufferMeta = new byte[65535];
                DatagramPacket pMeta = new DatagramPacket(bufferMeta, bufferMeta.length);
                s.receive(pMeta);

                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(pMeta.getData()));
                long tamf = dis.readLong();
                String cancion = dis.readUTF();
                int tambytes = dis.readInt();

                System.out.println("\nRecibiendo: " + cancion + " (" + tamf + " bytes)");

                // 2. Crear pipe para streaming
                PipedOutputStream pos = new PipedOutputStream();
                PipedInputStream pis = new PipedInputStream(pos,(int)tamf);
                System.out.println("buffer de pipe de "+(int)tamf+" bytes");

                // 3. Hilo reproductor
                Thread reproductor = new Thread(() -> {
                    try {
                        Player player = new Player(pis);
                        System.out.println("Reproduciendo en streaming: " + cancion);
                        player.play();
                        System.out.println("Reproducción finalizada.");
                    } catch (JavaLayerException e) {
                        System.err.println("Error al reproducir: " + e.getMessage());
                    }
                });
                reproductor.start();

                // 4. Recibir fragmentos y enviarlos al pipe
                long recibidos = 0;
                int k = 0;

                if (tamf > tam) {
                    int tp = (int) (tamf / tam);
                    for (int j = 0; j < tp; j++) {
                        DatagramPacket pp = new DatagramPacket(new byte[65535], 65535);
                        s.receive(pp);
                        pos.write(pp.getData(), 0, pp.getLength());
                        recibidos += pp.getLength();
                        System.out.println("Fragmento " + (j + 1) + "/" + tp + " recibido y enviado al reproductor");
                    }

                    if (tamf % tam > 0) {
                        DatagramPacket pp = new DatagramPacket(new byte[65535], 65535);
                        s.receive(pp);
                        pos.write(pp.getData(), 0, pp.getLength());
                        recibidos += pp.getLength();
                        System.out.println("Fragmento final (sobrantes) recibido");
                    }
                } else {
                    DatagramPacket pp = new DatagramPacket(new byte[65535], 65535);
                    s.receive(pp);
                    pos.write(pp.getData(), 0, pp.getLength());
                    recibidos += pp.getLength();
                    System.out.println("Archivo pequeño recibido de una vez");
                }

                pos.close(); // Importante: cerrar para que el Player termine
                System.out.println("Archivo completamente recibido: " + recibidos + " bytes enviados al reproductor\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}