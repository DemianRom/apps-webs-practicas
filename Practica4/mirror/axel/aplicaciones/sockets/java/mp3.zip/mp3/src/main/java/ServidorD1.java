import java.io.*;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.StandardSocketOptions;

public class ServidorD1 {
    public static void main(String[] args) {
        int port = 12345; // Puerto en el que el servidor escuchará
        String filePath = "Beautiful_Things.mp3"; // Ruta del archivo MP3

        try {
            File f = new File("");
            long tam = f.length();
            System.out.println("Ruta raiz: "+f.getAbsolutePath());
            DatagramSocket serverSocket = new DatagramSocket(port);
            serverSocket.setOption(StandardSocketOptions.SO_REUSEADDR, true);
            System.out.println("Servidor esperando peticiones en el puerto " + port);

            while (true) {
                //Socket clientSocket = serverSocket.accept();
                DatagramPacket p = new DatagramPacket(new byte[65535], 65535);
                serverSocket.receive(p);
                String comando = new String(p.getData(),0,p.getLength());
                int pto_cl = p.getPort();
                InetAddress addr_cl = p.getAddress();
                System.out.println("Recibiendo comando: "+comando + " desde "+addr_cl+":"+pto_cl);
                if(comando.compareToIgnoreCase("envia")==0){
                System.out.println("enviando el tamaño de canción: ");
                File f1 = new File(filePath);
                
                ByteArrayOutputStream baos= new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(baos);
                dos.writeLong(tam);
                dos.flush();
                byte[] btam = baos.toByteArray();        
                DatagramPacket p1 = new DatagramPacket(btam, btam.length, addr_cl, pto_cl);
                serverSocket.send(p1);
                DatagramPacket p2 = new DatagramPacket(new byte[65535], 65535);
                serverSocket.receive(p2);
                String comando2 = new String(p2.getData(),0,p2.getLength());
                    System.out.println("Recibiendo señal de envio: "+comando2);
                if(comando2.compareToIgnoreCase("listo")==0){
                // Envía el archivo MP3 al cliente
                    System.out.println("enviando..");
                sendFile(serverSocket, filePath, p.getAddress(), p.getPort());
                }else{
                    System.out.println("No se recibio la señal");
                    System.exit(1);
                }//else
                }//if
            }//while
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//main

    private static void sendFile(DatagramSocket sSocket, String filePath,InetAddress dst,int dst_port) {
        try {
            //OutputStream out = sSocket.getOutputStream();
        
            FileInputStream fileInputStream = new FileInputStream(filePath); 
            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                DatagramPacket p1 = new DatagramPacket(buffer,buffer.length, dst, dst_port);
                p1.setLength(bytesRead);
                sSocket.send(p1);
//                out.write(buffer, 0, bytesRead);
//                out.flush();
                // Control de flujo: Simula un pequeño retraso para evitar saturar al cliente
                Thread.sleep(10);
            }

            System.out.println("Archivo enviado correctamente.");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }//catch //finally {
//            try {
//                sSocket.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
    }//sendFile
}//class