import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;
import java.io.*;
import java.net.*;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;

public class ReproduceC1 {
    public static void main(String[] args) {
        String filePath = "Beautiful_Things.mp3"; // Ruta del archivo MP3

        try {
            File f = new File("");
            System.out.println("Ruta:"+f.getAbsolutePath());
            Socket cl = new Socket("127.0.0.1",12345);
            System.out.println("Conectado al servidor, obteniendo archivo..");
            BufferedInputStream bis = new BufferedInputStream(cl.getInputStream());
            // Crear un FileInputStream para el archivo MP3
            //FileInputStream fileInputStream = new FileInputStream(filePath);

            // Crear un reproductor (Player) con el flujo de entrada
            //Player player = new Player(fileInputStream);
            Player player = new Player(bis);
            System.out.println("Reproduciendo archivo MP3");

            // Reproducir el archivo MP3
            player.play();

            System.out.println("Reproducción finalizada.");
            player.close(); 
            bis.close();
            cl.close();
        } catch (FileNotFoundException e) {
            System.err.println("Archivo no encontrado: " + e.getMessage());
        } catch (JavaLayerException e) {
            System.err.println("Error al reproducir el archivo MP3: " + e.getMessage());
        } catch (IOException io){
            io.printStackTrace();
        }
    }//main
}//class