import java.net.*;
import java.io.*;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

/**
 *
 * @author axele
 */
public class SecoD {
    public static void main(String[] args){
      try{  
          int pto=9999,tam=40000;
          String msj="";
          DatagramSocket s = new DatagramSocket(pto);
          s.setReuseAddress(true);
         // s.setBroadcast(true);
          System.out.println("Servidor iniciado... esperando datagramas..");
          for(;;){
              byte[] b = new byte[65535];
              DatagramPacket p = new DatagramPacket(b,b.length);
              s.receive(p);
              DataInputStream dis = new DataInputStream(new ByteArrayInputStream(p.getData()));
              long tamf = dis.readLong();
              String cancion = dis.readUTF();
              int tambytes = dis.readInt(),nb,k=0;
              byte[] archivo = new byte[(int)tamf];
              long recibidos=0;
              System.out.println("archivo recibido: "+cancion+" de "+tamf+" bytes" );
              if(tamf>tam){
                  System.out.println("Preparado para recibir segmentos de la cancion..");
                      int tp = (int) (tamf / tam);
                      for (int j = 0; j < tp; j++) {
                        DatagramPacket pp = new DatagramPacket(new byte[65535],65535);
                        s.receive(pp);
                        recibidos = recibidos + pp.getLength();
                        byte[]tmp = pp.getData();
                          System.out.println("recibiendo segmento desde k:"+k);
                        for(int l=0;l<pp.getLength();l++)
                          archivo[k++]= tmp[l];
                        System.out.println("hasta k:"+k);
                      }//for
                      
                      
                      if (tamf % tam > 0) { //bytes sobrantes  
                          System.out.println("recibiendo bytes sobrantes..");
                            int sobrantes = (int)tamf % tam;
                            DatagramPacket pptmp = new DatagramPacket(new byte[65535],65535);
                            s.receive(pptmp);
                            byte[]tmp2 = pptmp.getData();
                            System.out.println("Poniendo sobrantes desde k:"+k);
                        for(int ll=0;ll <pptmp.getLength();ll++)
                          archivo[k++]= tmp2[ll];
                        System.out.println("Sobrantes hasta k:"+k);
                     }//if
                      
              }else{
                  DatagramPacket pptmp = new DatagramPacket(new byte[65535],65535);
                  s.receive(pptmp);
                  byte[]tmp2 = pptmp.getData();
                  System.out.println("Valor de k:"+k);
                  for(int ll=0;ll <pptmp.getLength();ll++)
                     archivo[k++]= tmp2[ll];
                  System.out.println("Valor de k:"+k);
              }//else
              
              System.out.println("Se intentará reproducir el archivo" + cancion+ " de "+tamf+" bytes..");
              ByteArrayInputStream bais = new ByteArrayInputStream(archivo);
              /*************/
              try{
                 // Crear un reproductor (Player) con el flujo de entrada
                 Player player = new Player(bais);
                 System.out.println("Reproduciendo archivo MP3: " + cancion);
                 // Reproducir el archivo MP3
                 player.play();
                 System.out.println("Reproducción finalizada.");
               } catch (JavaLayerException e) {
                  System.err.println("Error al reproducir el archivo MP3: " + e.getMessage());
               }//catch  
              /**************/
              
          }//for
          
      }catch(Exception e){
          e.printStackTrace();
      }//catch
        
    }//main
}
