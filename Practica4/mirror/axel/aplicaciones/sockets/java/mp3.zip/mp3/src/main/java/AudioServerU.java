import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class AudioServerU {
    private static final int PORT = 9876;
    private static final int BUFFER_SIZE = 4096;//4096;

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress address = InetAddress.getByName("localhost");
            
            File audioFile = new File("Beautiful_Things.mp3");
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(audioFile));
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead, cont =0;

            while ((bytesRead = bis.read(buffer)) != -1) {
                DatagramPacket packet = new DatagramPacket(buffer, bytesRead, address, PORT);
                socket.send(packet);
                System.out.println("transmitido el paquete "+(cont++)+" con "+bytesRead+" bytes");
                try{
                   Thread.sleep(10000); // Controlar la velocidad de envío
                }catch(InterruptedException ie){}
            }

            bis.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
