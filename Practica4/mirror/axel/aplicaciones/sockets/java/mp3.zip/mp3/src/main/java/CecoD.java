import java.net.*;
import java.io.*;
import java.util.Arrays;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 *
 * @author axele
 */
public class CecoD {

    public static void main(String[] args) {
        try {
            int pto = 9999;
            String dir = "127.0.0.1";
            InetAddress dst = InetAddress.getByName(dir);
            int tam = 40000, x = 0;
            DatagramSocket cl = new DatagramSocket();
            JFileChooser jf = new JFileChooser();
            // Crear un filtro para archivos .mp3
            FileNameExtensionFilter imageFilter = new FileNameExtensionFilter("Música (*.mp3)", "mp3");
            jf.addChoosableFileFilter(imageFilter);
            //while (true) {
               byte[] b;
                System.out.println("Lanzando Filechooser..");
                int r;
                if((r=jf.showOpenDialog(null))==JFileChooser.APPROVE_OPTION){
                    File ff = jf.getSelectedFile();
                    long tamf = ff.length();
                    String nombre = ff.getName();
                    String ruta = ff.getAbsolutePath();
                    DataInputStream dis = new DataInputStream(new FileInputStream(ruta));
                    b = new byte[(int)tamf];
                    int n = dis.read(b);
                    System.out.println("Tam archivo a ser enviado: "+tamf+" vs: "+n);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    DataOutputStream dos = new DataOutputStream(baos);
                    dos.writeLong(tamf);
                    dos.writeUTF(nombre);
                    dos.writeInt(b.length);
                    dos.flush();
                    byte[] tmp0 = baos.toByteArray();
                    DatagramPacket p0 = new DatagramPacket(tmp0, tmp0.length, dst, pto);
                    cl.send(p0);
                    System.out.println("enviando metainformacion..");
                    if (b.length > tam) {
                        //byte[] b_eco = new byte[b.length];
                        int tp = (int) (b.length / tam);
                        for (int j = 0; j < tp; j++) {
                            x++;
                            byte[] tmp = Arrays.copyOfRange(b, j * tam, ((j * tam) + (tam)));
                            DatagramPacket p = new DatagramPacket(tmp, tmp.length, dst, pto);
                            cl.send(p);
                            System.out.println("Enviando fragmento " + x + "\ndesde:" + (j * tam) + " hasta " + ((j * tam) + (tam - 1)));
                            try{
                                Thread.sleep(400);
                            }catch(InterruptedException ie){}
                            
                        }//for
                        if (b.length % tam > 0) { //bytes sobrantes  
                            x++;
                            int sobrantes = b.length % tam;
                            System.out.println("sobrantes:" + sobrantes);
                            byte[] tmp = Arrays.copyOfRange(b, tp * tam, ((tp * tam) + sobrantes));
                            DatagramPacket p = new DatagramPacket(tmp, tmp.length, dst, pto);
                            cl.send(p);
                            //DatagramPacket p1 = new DatagramPacket(new byte[tam], tam);
                            //cl.receive(p1);
                            //byte[] bp1 = p1.getData();
                            //for (int i = 0; i < sobrantes; i++) {
                              //  b_eco[(tp * tam) + i] = bp1[i];
                            //}//for
                        }//if sobrantes

                    } else {
                        DatagramPacket p = new DatagramPacket(b, b.length, dst, pto);
                        cl.send(p);
                    }//else
                //}//else
            //}//while
         }//if chooser
        } catch (Exception e) {
            e.printStackTrace();
        }//catch
    }//main
}//class
