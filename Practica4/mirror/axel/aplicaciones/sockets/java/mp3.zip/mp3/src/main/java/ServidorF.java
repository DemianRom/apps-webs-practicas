import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.StandardSocketOptions;

public class ServidorF {
    public static void main(String[] args) {
        int port = 12345; // Puerto en el que el servidor escuchará
        String filePath = "Beautiful_Things.mp3"; // Ruta del archivo MP3

        try {
            File f = new File("");
            System.out.println("Ruta raiz: "+f.getAbsolutePath());
            ServerSocket serverSocket = new ServerSocket(port);
            serverSocket.setOption(StandardSocketOptions.SO_REUSEADDR, true);
            System.out.println("Servidor esperando conexiones en el puerto " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente conectado: " + clientSocket.getInetAddress());

                // Envía el archivo MP3 al cliente
                sendFile(clientSocket, filePath);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//main

    private static void sendFile(Socket clientSocket, String filePath) {
        try (OutputStream out = clientSocket.getOutputStream();
             FileInputStream fileInputStream = new FileInputStream(filePath)) {

            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
                out.flush();
                System.out.println("enviando "+ bytesRead+" bytes");
                // Control de flujo: Simula un pequeño retraso para evitar saturar al cliente
                Thread.sleep(10);
            }

            System.out.println("Archivo enviado correctamente.");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}