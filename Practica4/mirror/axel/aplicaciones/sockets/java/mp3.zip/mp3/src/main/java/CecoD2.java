import java.net.*;
import java.io.*;
import java.util.Arrays;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class CecoD2{
    public static void main(String[] args) {
        try {
            int pto = 9999;
            String dir = "127.0.0.1";
            InetAddress dst = InetAddress.getByName(dir);
            //int tam = 8192; // Tamaño más pequeño para mejor streaming (8KB)
            int tam = 40000;
            DatagramSocket cl = new DatagramSocket();
            JFileChooser jf = new JFileChooser();
            
            FileNameExtensionFilter mp3Filter = new FileNameExtensionFilter("Música (*.mp3)", "mp3");
            jf.addChoosableFileFilter(mp3Filter);
            
            System.out.println("Lanzando FileChooser...");
            int r;
            if ((r = jf.showOpenDialog(null)) == JFileChooser.APPROVE_OPTION) {
                File ff = jf.getSelectedFile();
                long tamf = ff.length();
                String nombre = ff.getName();
                String ruta = ff.getAbsolutePath();
                
                DataInputStream dis = new DataInputStream(new FileInputStream(ruta));
                
                // 1. Enviar metadatos primero
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(baos);
                dos.writeLong(tamf);
                dos.writeUTF(nombre);
                dos.writeInt(tam); // Enviar el tamaño de fragmento usado
                dos.flush();
                
                byte[] metadata = baos.toByteArray();
                DatagramPacket pMeta = new DatagramPacket(metadata, metadata.length, dst, pto);
                cl.send(pMeta);
                System.out.println("Metadatos enviados: " + nombre + " (" + tamf + " bytes)");
                
                // 2. Enviar el archivo en fragmentos pequeños para streaming
                byte[] buffer = new byte[tam];
                int bytesLeidos;
                int fragmentoNum = 0;
                
                while ((bytesLeidos = dis.read(buffer)) > 0) {
                    fragmentoNum++;
                    byte[] fragmento = Arrays.copyOf(buffer, bytesLeidos);
                    DatagramPacket p = new DatagramPacket(fragmento, fragmento.length, dst, pto);
                    cl.send(p);
                    System.out.println("Enviando fragmento " + fragmentoNum + " (" + bytesLeidos + " bytes)");
                    
                    // Pequeña pausa para no saturar la red y permitir streaming fluido
                    Thread.sleep(50);
                }
                
                System.out.println("Archivo enviado completamente. Total fragmentos: " + fragmentoNum);
                dis.close();
                cl.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}