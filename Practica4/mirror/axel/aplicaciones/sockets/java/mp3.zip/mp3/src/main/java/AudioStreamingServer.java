import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class AudioStreamingServer {
    private static final int PORT = 9876;
    private static final int BUFFER_SIZE = 50000;//4096;
    private static final int CIRCULAR_BUFFER_SIZE = 10; // Tamaño del buffer circular

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress clientAddress = InetAddress.getByName("localhost");
            byte[] buffer = new byte[BUFFER_SIZE];
            FileInputStream fis = new FileInputStream(new File("Beautiful_Things.mp3"));
            int bytesRead;
            /****************************************************/
            
            /****************************************************/
            int bitRate = 192; // Tasa de bits en kbps (ajusta según el archivo MP3)
            int delay = (int) ((BUFFER_SIZE * 8) / (bitRate * 1000)); // Retardo en milisegundos
            System.out.println("retardo calculado: "+ delay+" milisegundos");
            byte[][] circularBuffer = new byte[CIRCULAR_BUFFER_SIZE][BUFFER_SIZE];
            int head = 0;
            int tail = 0;
            int cont =0;
            while ((bytesRead = fis.read(buffer)) != -1) {
                circularBuffer[head] = buffer.clone();
                System.out.println("Enviando paquete "+(cont++)+" con  "+circularBuffer[tail].length +" bytes");
                head = (head + 1) % CIRCULAR_BUFFER_SIZE;

                if (head == tail) {
                    tail = (tail + 1) % CIRCULAR_BUFFER_SIZE;
                }
                System.out.println("indice a ser enviado: "+head+", tail:"+tail);
                DatagramPacket packet = new DatagramPacket(circularBuffer[tail], BUFFER_SIZE, clientAddress, PORT);
                socket.send(packet);
                //System.out.println("Enviando paquete"+(cont++)+" con  "+circularBuffer[tail].length +" bytes");
                tail = (tail + 1) % CIRCULAR_BUFFER_SIZE;

                Thread.sleep(10); //delay
            }

            fis.close();
            socket.close();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
