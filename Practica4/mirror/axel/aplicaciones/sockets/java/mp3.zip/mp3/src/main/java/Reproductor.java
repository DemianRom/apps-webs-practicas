import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;
import javazoom.jl.player.advanced.PlaybackEvent;
import javazoom.jl.player.advanced.PlaybackListener;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Reproductor {
    private static AdvancedPlayer player;
    private static boolean isPlaying = true;

    public static void main(String[] args) {
        String filePath = "Beautiful_Things.mp3"; // Ruta del archivo MP3

        try {
            FileInputStream fileInputStream = new FileInputStream(filePath);
            player = new AdvancedPlayer(fileInputStream);

            // Agregar un listener para manejar eventos de reproducción
            player.setPlayBackListener(new PlaybackListener() {
                @Override
                public void playbackFinished(PlaybackEvent evt) {
                    isPlaying = false;
                    System.out.println("Reproducción finalizada.");
                }
            });

            System.out.println("Reproduciendo archivo MP3: " + filePath);

            // Iniciar la reproducción en un hilo separado
            new Thread(() -> {
                try {
                    player.play();
                } catch (JavaLayerException e) {
                    System.err.println("Error al reproducir el archivo MP3: " + e.getMessage());
                }
            }).start();

            // Simular controles de reproducción
            Thread.sleep(5000); // Reproducir durante 5 segundos
            pause();
            Thread.sleep(2000); // Pausar durante 2 segundos
            resume();
            Thread.sleep(5000); // Reproducir otros 5 segundos
            stop();

        } catch (FileNotFoundException | JavaLayerException | InterruptedException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    // Método para pausar la reproducción
    public static void pause() {
        if (player != null && isPlaying) {
            player.stop();
            isPlaying = false;
            System.out.println("Reproducción pausada.");
        }
    }

    // Método para reanudar la reproducción
    public static void resume() {
        if (player != null && !isPlaying) {
            new Thread(() -> {
                try {
                    player.play();
                    isPlaying = true;
                    System.out.println("Reproducción reanudada.");
                } catch (JavaLayerException e) {
                    System.err.println("Error al reanudar la reproducción: " + e.getMessage());
                }
            }).start();
        }
    }

    // Método para detener la reproducción
    public static void stop() {
        if (player != null) {
            player.close();
            isPlaying = false;
            System.out.println("Reproducción detenida.");
        }
    }
}