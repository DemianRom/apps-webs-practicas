import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Reproduce {
    public static void main(String[] args) {
        String filePath = "Beautiful_Things.mp3"; // Ruta del archivo MP3

        try {
            File f = new File("");
            System.out.println("Ruta:"+f.getAbsolutePath());
            
            // Crear un FileInputStream para el archivo MP3
            FileInputStream fileInputStream = new FileInputStream(filePath);

            // Crear un reproductor (Player) con el flujo de entrada
            Player player = new Player(fileInputStream);

            System.out.println("Reproduciendo archivo MP3: " + filePath);

            // Reproducir el archivo MP3
            player.play();

            System.out.println("Reproducción finalizada.");
        } catch (FileNotFoundException e) {
            System.err.println("Archivo no encontrado: " + e.getMessage());
        } catch (JavaLayerException e) {
            System.err.println("Error al reproducir el archivo MP3: " + e.getMessage());
        }
    }
}