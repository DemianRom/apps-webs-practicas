package P3;
public class Launcher {
    
    public static void main(String[] args1) {
        ReproductorMP3.main(args1);
    }
}
