package P3;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import java.io.File;

public class ReproductorMP3 extends Application {

    private MediaPlayer mediaPlayer;

    @Override
    public void start(Stage primaryStage) {
        // 1. Obtener la lista de argumentos pasados a la aplicación JavaFX
       /*
        Parameters params = getParameters();
        if (params.getRaw().isEmpty()) {
            System.err.println("Error: Debes proporcionar la ruta del archivo MP3 como argumento de línea de comandos.");
            Platform.exit();
            return;
        } */
       File f=null;
       String ruta="";
       String archivo="";
       try{
           f= new File("");
           ruta = f.getAbsolutePath();
           archivo=ruta+"\\Beautiful_Things.mp3";
       }catch(Exception e){
         e.printStackTrace();
       }//catch

        // El primer argumento es la ruta del archivo MP3
        //String mp3FilePath = params.getRaw().get(0);
        String mp3FilePath = "Beautiful_Things.mp3";
        File mp3File = new File(mp3FilePath);

        if (!mp3File.exists() || !mp3File.isFile()) {
            System.err.println("Error: Archivo MP3 no encontrado o ruta inválida: " + mp3FilePath);
            Platform.exit();
            return;
        }

        try {
            // Convertir la ruta del archivo a un formato URI que Media pueda usar
            String source = mp3File.toURI().toString();
            Media media = new Media(source);
            
            // 2. Crear el MediaPlayer
            mediaPlayer = new MediaPlayer(media);

            // 3. Manejar la reproducción y el cierre de la aplicación

            // Reproducir tan pronto como esté listo
            mediaPlayer.setOnReady(() -> {
                System.out.println("Reproduciendo: " + mp3File.getName());
                mediaPlayer.play();
            });

            // Cerrar la aplicación cuando la reproducción termine
            mediaPlayer.setOnEndOfMedia(() -> {
                System.out.println("Reproducción terminada. Saliendo.");
                mediaPlayer.stop(); // Detener el reproductor
                Platform.exit();    // Cerrar el hilo de JavaFX
            });

            // Manejar errores
            mediaPlayer.setOnError(() -> {
                System.err.println("Error del MediaPlayer: " + mediaPlayer.getError());
                Platform.exit();
            });

        } catch (Exception e) {
            System.err.println("Error al inicializar el reproductor de medios: " + e.getMessage());
            Platform.exit();
        }
    }

    public static void main(String[] args) {
        // Ejecutar la aplicación JavaFX, pasando los argumentos de la línea de comandos
        // directamente al método start.
        launch(args);
    }
}