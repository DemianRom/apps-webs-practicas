
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;


/**
 *
 * @author Axel Ernesto
 */
public class Servidor {
 public static void main(String[] args){
     try{
         ServerSocket s = new ServerSocket(1234);
         System.out.println("Servidor iniciado en el puerto "+ s.getLocalPort());
         System.out.println("Con un buffer de " + s.getOption(StandardSocketOptions.SO_RCVBUF));
         for(;;){
             Socket cl = s.accept();
             System.out.println("Cliente conectado desde "+cl.getInetAddress()+":"+cl.getPort());
         /*
             DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
             DataInputStream dis = new DataInputStream(cl.getInputStream());
             System.out.println("Recibiendo los siguientes datos");
             int v1 = dis.readInt();
             float v2 = dis.readFloat();
             String v3 = dis.readUTF();
             System.out.println("v1:"+v1+", v2:"+v2+", v3:"+v3);
             System.out.println("Enviando respuesta..");
             dos.writeInt(4);
             dos.writeFloat(5.0f);
             dos.writeUTF("seis");
             dos.flush();
             dis.close();
             dos.close();
*/
             BufferedReader br = new BufferedReader(new InputStreamReader(cl.getInputStream(),"UTF-8"));
             PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream(),"UTF-8"));
             String nombre = br.readLine();
             try{             
                    System.setOut(new PrintStream(System.out,true,StandardCharsets.UTF_8));
                    System.out.println("Recibiendo el nombre "+nombre+ " devolviendo saludo personalizado");
                    String saludo = "Hola "+nombre+" Recibe un saludo desde la aplicación servidor..";
                    pw.println(saludo);
                    pw.flush();
                    System.out.println("Se envió el nombre "+nombre +" al servidor");
            }catch(Exception u){
                    System.err.println("charset no soportado");
            }//catch
             br.close();
             pw.close();
             cl.close();
         }//for
     }catch(Exception e){
         e.printStackTrace();
     }
 }    
}
