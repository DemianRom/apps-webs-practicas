
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;



/**
 *
 * @author Axel Ernesto
 */
public class Cliente {
 public static void main(String[] args){
     try{
         Socket cl = new Socket("::1",1234);
       /*  DataOutputStream dos = new DataOutputStream(cl.getOutputStream());
         DataInputStream dis = new DataInputStream(cl.getInputStream());
         dos.writeInt(1);
         dos.writeFloat(2.0f);
         dos.writeUTF("tres");
         dos.flush();
         System.out.println("Recibiendo datos");
         int v4 = dis.readInt();
         float v5 = dis.readFloat();
         String v6 = dis.readUTF();
         System.out.println("Se recibieron los datos v4:"+v4+", v5:"+v5+", v6:"+v6);
         dis.close();
         dos.close();
        */
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in,"UTF-8"));
         System.out.println("Escribe tu nombre:");
         String nombre = br.readLine();
         PrintWriter pw = new PrintWriter(new OutputStreamWriter(cl.getOutputStream(),"UTF-8"));
         BufferedReader br1 = new BufferedReader(new InputStreamReader(cl.getInputStream(),"UTF-8"));
         pw.println(nombre);
         pw.flush();
         //PrintWriter pw2 = new PrintWriter(new OutputStreamWriter(System.out,"ISO-8859-1"));
         //reconfiguración de System.out
         try{             
             System.setOut(new PrintStream(System.out,true,StandardCharsets.UTF_8));
             System.out.println("Se envió el nombre "+nombre +" al servidor");
             System.out.flush();
             String saludo = br1.readLine();
             System.out.println("Saludo recibido con el mensaje: "+saludo);
             System.out.flush();
            
     }catch(UnsupportedEncodingException u){
         
     }//catch
         br.close();
         br1.close();
         pw.close();
         cl.close();
     }catch(Exception e){
         e.printStackTrace();
     }
 }   //main 
}
