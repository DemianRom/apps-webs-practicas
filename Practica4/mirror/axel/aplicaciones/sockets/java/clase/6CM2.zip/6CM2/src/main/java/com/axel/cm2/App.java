/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.axel.cm2;

/**
 *
 * @author Axel Ernesto
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
